TSOR-5-8s-Engine
================

TSOR 5-8s Engine (0.625m Liquid Fueled Engine)
Author: Poodmund

Installation:

Please extract included GameData folder into the root directory of your KSP install.

License:

This Add-On is licensed under the CC BY-NC-SA 3.0 license.

Credits:

This Add-On included and utilizes the SmokeScreen Plugin created by Sarbian licensed under the BSD 2-Clause License. More information about SmokeScreen can be found by following this URL: http://forum.kerbalspaceprogram.com/threads/71630